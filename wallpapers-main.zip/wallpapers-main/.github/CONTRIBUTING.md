# How to make a PR

## 1. Fork this repository

![fork](./images/fork.png)

## 2. Make your changes

![changes](./images/upload.png)

## 3. Make a pull request

![pr](./images/pr.png)

***
